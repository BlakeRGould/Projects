
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author blake
 */
public class Guest {
    //public int id;
    public String age;
    public Point location;
    public Point destination;
    
    // An integer to pair w the Attraction: expTime:
    // Determines how long the individual has been on their current
    // ride in minutes
    public double expTimer;
    
    // A couple of booleans to determine where the guest currently is
    public boolean onRide;
    public boolean inLine;
    
    public Attraction attractionDestination;
    public ArrayList<Attraction> ridesRidden = new ArrayList<>();
    public boolean tracking = false;
    public int hungerStatus;
    
    // This arrayList records all of the previous locations that a user has been in since
    // the last time they were on an attraction, ate food, etc.
    public ArrayList<Point> previousLocations = new ArrayList<>();
    
    public Guest(String age) {
        this.age = age;
        this.location = new Point();
    }
    
    
    public void setDestination(Attraction att) {
        if (att.type.equalsIgnoreCase("Ride")) {
            destination = att.getAccessPoint();
            attractionDestination = att;
        } 
//        else if (att.type.equalsIgnoreCase("Restaurant")) {
//            destination = att.restuarantAccessPoint;
//            attractionDestination = att;
//        }
        
    }
    
    public void setLocation (int x, int y) {
        this.location = new Point(x, y);
    }
    
    public void setLocation (Point p) {
        this.location = p;
    }
    
    public void setHungerStatus (int x) {
        hungerStatus = x;
    }
    
    public int getHungerStatus () {
        return hungerStatus;
    }
    
    public void draw(Graphics g)
    {
        g.setColor(Color.darkGray);
        if (tracking) {
            g.setColor(Color.white);
        }
        
        g.fillOval((int)location.getX() + 3, (int)location.getY() + 3, 4, 4);
        if (tracking) {
            g.setColor(Color.red);
            g.drawOval((int)location.getX() + 3, (int)location.getY() + 3, 4, 4);
        }
        
    }

}
