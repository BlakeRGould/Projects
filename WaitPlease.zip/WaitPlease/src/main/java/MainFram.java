
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.Timer;
import java.util.TimerTask;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JToggleButton;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author blake
 */
public class MainFram extends JFrame{
    

    
    public int dailySecondsSurpassed = 0;
    public Integer[] currentTime = {0,0,0};
    public JLabel timeLabel = new JLabel();
    
    public int horizontalSpaces;
    public int verticalSpaces;
    public Rectangle[][] spaces;
    public Boolean[][] bools;
    public Boolean[][] fills;
    public Boolean[][] occupied;
    public int blockSize;
    public double xSize;
    public double ySize;
    public boolean shiftPressed;
    int shifti = -1;
    int shiftj = -1;
    //public Attraction leaving;
    
    public boolean labelsShowing = true;
    public String saveFileLocation = "SaveFills.txt";
    
    public ArrayList<Attraction> rides = new ArrayList<>();
    public ArrayList<Attraction> restaurants = new ArrayList<>();
            
    public ArrayList<Guest> guests = new ArrayList<>();
    
    public JList list = new JList();

    public DefaultListModel trackingModel = new DefaultListModel();
    
    public boolean running = true;
    
    public Timer tmr = new Timer();
    
    
    public boolean statsShowing = false;
    public boolean trackingShowing = false;
    
    public JPanel panel;
    
    public Guest guest = new Guest("");
    
    public MainFram()  {
        shownTrackerList = new JList<>();
        shownTimeLabel = new JLabel();
        shownList = new JList<>();
        
        
        
        
        
        
        
        
        
        

        
        Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        
        
        blockSize = 10;
        size = Toolkit.getDefaultToolkit().getScreenSize();
        xSize = size.getWidth();
        ySize = size.getHeight();
        horizontalSpaces = (int) xSize / blockSize;
        
        verticalSpaces = (int) ySize / blockSize;
        
        spaces = new Rectangle[horizontalSpaces][verticalSpaces];
        bools = new Boolean[horizontalSpaces][verticalSpaces];
        fills = new Boolean[horizontalSpaces][verticalSpaces];
        occupied = new Boolean[horizontalSpaces][verticalSpaces];
        
        
        int currx = 0;
        int curry = 0;
        for (int i = 0; i < horizontalSpaces; i++) {
            for (int j = 0; j < verticalSpaces; j++) {
                Point p = new Point(currx, curry);
                
                curry += blockSize;
                Dimension d = new Dimension(blockSize, blockSize);
                spaces[i][j] = new Rectangle(p, d);
                bools[i][j] = false;
                fills[i][j] = false;
                occupied[i][j] = false;
                
            }
            currx += blockSize;  
            curry = 0;
        }
        
        
        
        
        
        
        
        // Sets the starting time tp 7 o'clock
        
        dailySecondsSurpassed += (7 * 3600);
        
        
        
        
        
        
        
        
        load();
        
        // ADD THE rides 
        //(0)
        Attraction hauntedMansion = new Attraction("Haunted Mansion", 1125, "Adult", 7.5, 10);
        hauntedMansion.setGraphics(250, 160, 200, 100, Color.magenta);
        rides.add(hauntedMansion);
        
        //(1)
        Attraction spaceMountain = new Attraction("Space Mountain", 5000, "Young Adult", 2.5, 20);
        spaceMountain.setGraphics(1290, 370, 200, 100, Color.white);
        rides.add(spaceMountain);
        
        //(2)
        Attraction splashMountain = new Attraction("Splash Mountain", 3000, "Young Adult", 11, 15);
        splashMountain.setGraphics(30, 300, 100, 70, Color.BLUE);
        rides.add(splashMountain);
        
        //(3)
        Attraction dumbo = new Attraction("Dumbo", 7500, "Child", 1.5, 5);
        dumbo.setGraphics(1200, 150, 100, 100, Color.gray);
        rides.add(dumbo);
        
        //(4)
        Attraction mermaid = new Attraction("The Little Mermaid", 1636, "Child", 6, 0);
        mermaid.setGraphics(1010, 130, 200, 50, Color.cyan);
        rides.add(mermaid);
        
        //(5)
        Attraction peopleMover = new Attraction("The People Mover", 782, "Adult", 10, 0);
        peopleMover.setGraphics(1100, 460, 200, 50, Color.gray);
        rides.add(peopleMover);
        
        // (6)
        Attraction pooh = new Attraction("Winnie the Pooh", 4235, "Child", 3, 5);
        pooh.setGraphics(920, 240, 200, 50, Color.yellow);
        rides.add(pooh);
       
        // (7)
        Attraction pirates = new Attraction("Pirates of the Carribean", 1125, "Young Adult", 8.5, 10);
        pirates.setGraphics(270, 500, 100, 100, Color.RED);
        rides.add(pirates);
        // (8)
        Attraction bigThunder = new Attraction("Big Thunder Mountain Railroad", 1500, "Young Adult", 3.5, 10);
        bigThunder.setGraphics(50, 180, 100, 100, Color.GRAY);
        rides.add(bigThunder);       
        //(9)
        Attraction sevenDwarfs = new Attraction("7 Dwarfs Mine Train", 3000, "Young Adult", 2.5, 20);
        sevenDwarfs.setGraphics(910, 170, 100, 100, Color.green);
        rides.add(sevenDwarfs);
        //(10)
        Attraction peterPan = new Attraction("Peter Pan's Flight", 4500, "Adult", 3, 15);
        peterPan.setGraphics(590, 200, 100, 100, Color.green);
        rides.add(peterPan);
        //(11)
        Attraction buzzLightYear = new Attraction("Buzz Lightyear's Space Ranger Spin", 4500, "Child", 4, 5);
        buzzLightYear.setGraphics(970, 560, 100, 100, new Color(75,0,130));
        rides.add(buzzLightYear);        
        //(12)
        Attraction carrousel = new Attraction("Prince Charming Regal Carrousel", 2553, "Child", 2, 0);
        carrousel.setGraphics(710, 90, 100, 100, Color.white);
        rides.add(carrousel);
        
//        Attraction StarLightCafe = new Attraction("StarLight Cafe", "Quick Service");
//        StarLightCafe.setGraphics(900, 600, 100, 30, Color.ORANGE);
//        restaurants.add(StarLightCafe);
        
        
        
//         leaving = new Attraction("EXIT", 10, 10000, "All");
//        leaving.setGraphics(600, 800, 50, 50, Color.pink);
        
        
        
    //     ADD THE Initial GUESTS
        for (int x = 130; x <= 1280; x += 10) {
            for (int y = 830; y <= 870; y += 10) {
                Random random = new Random();
                int rand = random.nextInt(3);
                Guest guest = new Guest("Adult");
                switch (rand) {
                    case 0:
                        guest = new Guest("Child");
                        break;
                    case 1:
                        guest = new Guest("Adult");
                        break;
                    case 2:
                        guest = new Guest("Young Adult");
                        break;
                    default:
                        break;
                }
                guest.setLocation(x, y);
                guest.setDestination(determineDestination(guest));
                
                guests.add(guest);
                occupied[x/10][y/10] = true;
                
                
            }
        }
        guest = new Guest("Adult");
        guest.setLocation(100, 830);
        guest.tracking = true;
        
        guest.setHungerStatus(0);
        guest.setDestination(determineDestination(guest));
        guests.add(guest);
        occupied[10][83] = true;
        
        ArrayList<TimerTask> peopleAdder = new ArrayList<>();
        int delay = 0;
        for (int i = 0; i < 2; i ++) {
            delay += 25000;
            
            TimerTask addMoreGuests = new TimerTask() {
                @Override
                public void run() {
                    for (int x = 130; x <= 1280; x += 10) {
                        for (int y = 830; y <= 870; y += 10) {
                            Random random = new Random();
                            int rand = random.nextInt(3);
                            Guest guest = new Guest("Adult");
                            switch (rand) {
                                case 0:
                                    guest = new Guest("Child");
                                    break;
                                case 1:
                                    guest = new Guest("Adult");
                                    break;
                                case 2:
                                    guest = new Guest("Young Adult");
                                    break;
                                default:
                                    break;
                            }
                            guest.setLocation(x, y);
                            guest.setDestination(determineDestination(guest));

                            guests.add(guest);
                            occupied[x/10][y/10] = true;    
                        }
                    }

                }
            }; 
            peopleAdder.add(addMoreGuests);
            tmr.schedule(addMoreGuests, delay);
        }
        
       
        
        tmr = new Timer();
        
        TimerTask tmrTask = new TimerTask() {
            @Override
            public void run() {
                if (running) {
                    passTime();    
                } else {
                    panel.repaint();
                }
                
            }
        };
        
        TimerTask updateWaitTimes = new TimerTask() {
            @Override
            public void run() {
                configureWaits();
                
            }
        };
        
//        TimerTask destinationReorientation = new TimerTask() {
//            @Override
//            public void run () {
//                for (Guest g : guests) {
//                    g.setDestination(determineDestination(g));
//                
//                    
//                }
//            }
//        };
        
        TimerTask aSecondPasses = new TimerTask() {
            @Override
            public void run() {
                
                updateLists(); 
                dailySecondsSurpassed += 1;
                // Gives hours
                currentTime[0] = dailySecondsSurpassed / 3600;
                // Gives minutes
                currentTime[1] = (dailySecondsSurpassed % 3600) / 60;
                // Gives seconds
                currentTime[2] = (dailySecondsSurpassed - (currentTime[0] * 3600) - (currentTime[1] * 60));
                shownTimeLabel.setText(currentTime[0] + ":" + currentTime[1] + ":" + currentTime[2]);
                if (currentTime[1] == 0 && currentTime[2] == 0) {
                    createEntry(currentTime[0]);
                }
                panel.repaint();
            }
        };
        
        tmr.schedule(aSecondPasses, 0, 1000);
        
        TimerTask fiveSecondsPasses = new TimerTask() {
            @Override
            public void run() {
                checkForRespawn();
            }
        };
        
        //tmr.schedule(fiveSecondsPasses, 0, 5000);
            
        
        
        //tmr.schedule(destinationReorientation, 0, 50);
        
        // Creates and Loads TimerTasks to transfer people on and off rides at
        // the specified time interval (outFlowTime) for each ride
        ArrayList<TimerTask> rideTransfers = new ArrayList<>();
        for (Attraction a : rides) {
            TimerTask newTask = new TimerTask() {
                @Override
                public void run() {
                    if (running) {
                        // By exiting the ride first, we ensure that a person doesnt get on the ride 
                        // and then exit it immediately
                        rideExit(a);
                        rideLoad(a);    
                    }
                    
                }
            };
            rideTransfers.add(newTask);
            // The task is called at half the outflowtime so that
            // the time for one individual to get on and off the ride
            // is equal to the outFlowTime (oft / 2) * 2 = oft;
            
            tmr.schedule(newTask, 0, a.outFlowTime / 2);
        }
        
        TimerTask unloadClosedRides = new TimerTask() {
            @Override
            public void run() {
                for (Attraction a : rides) {
                    if (a.closed) {
                        rideEvac(a);     
                    }
                       
                }
                
            }
            
        
        };
        
        tmr.schedule(unloadClosedRides, 0, 50);
        
        
        
        
        
        shownList = list;
        
        
        panel = new myPanel();
        
        
        
        
        
        panel.setVisible(true);
        this.setSize(size);
        this.show(); 
        
     
        
        
        
        tmr.schedule(tmrTask, 0, 50);
        tmr.schedule(updateWaitTimes, 0, 1000);
        
             
        
        // Every 60,000 milliseconds, a minute passes
        TimerTask oneTenthMinutePassed = new TimerTask() {
            @Override
            public void run() {
                for (Guest g : guests) {
                    
                    if (g.onRide) {
                        g.expTimer += 0.1;   
                        
                    }  
                    
                }
                
            }
                
        };
        tmr.schedule(oneTenthMinutePassed, 0, 6000);
        
        TimerTask threeMinutesPass = new TimerTask() {
            @Override
            public void run() {
                for (Guest g: guests) {
                    boolean marathon = true;
                    for (Attraction a: rides) {
                        if (!g.ridesRidden.contains(a)) {
                            marathon = false;
                        }
                     }
                    if (marathon) {
                        g.ridesRidden = new ArrayList<>();
                    }
                    
                }

                    
                
            }
        };
        
        tmr.schedule(threeMinutesPass, 0, 180000);
        

        DefaultListModel model = new DefaultListModel();
            for (Attraction a : rides) {
                model.addElement(a.toString());
            }
            list = new JList(model);
            list.setLocation(900, 0);
            panel.add(list);
            list.setVisible(true);
 
            
        
        shownTrackerList.setModel(trackingModel);
        shownTrackerList.setLocation(900, 900);
        shownTrackerList.setVisible(true);
        
        
        
        
        
        initComponents();
        simEndedArea.setVisible(false);
        newDayButton.setVisible(false);
        shownList.setModel(model);
        
        ageLabel.setText("The age group of the subject is " + guest.age);
        
        
        JFrame closingsFrame = new JFrame();
        JPanel closingsPanel = new JPanel();
        
        shownTrackerList.setModel(trackingModel);
        for (Attraction a : rides) {
            JToggleButton closedButton = new JToggleButton("X");
            closedButton.setSelected(false);
            closedButton.addActionListener((e) -> {
                if (closedButton.isSelected()) {
                    a.closed = true;
                } else {
                    a.closed = false;
                }
            });
            closedButton.setText(a.name);
            closingsPanel.add(closedButton);
   
        }
        
        pauseButton.setBounds(500, 500, 50, 50);
        pauseButton.addActionListener((e) -> {
            running = !running;
        });
        
        //Fullscreen
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        closingsFrame.add(closingsPanel);
        closingsFrame.setSize(400, 300);
        closingsFrame.setAlwaysOnTop(true);
        closingsFrame.show();
        
        
        
        /*try {
                Clip clip = AudioSystem.getClip();
                File file = new File("C:\\Users\\blake\\Desktop\\Piano Sounds\\Main Street USA Area Music - Loop.wav");
                clip.open(AudioSystem.getAudioInputStream(file));
                clip.start();


            }catch(Exception e) {
                e.printStackTrace();
        }*/     
        
        
        
        
        simSkip.setVisible(false);
        reportLoc.setVisible(false);
        printReportButton.setVisible(false);
        
        
        
        
        
        
    }
    
    public void createEntry(int x) {
        ArrayList<Integer> curr = new ArrayList<>();
        curr.add(x);
        for (Attraction a: rides) {
            curr.add(a.getWaitTime());
        }
        entries.add(curr);
        
    }
    
    ArrayList<ArrayList<Integer>> entries = new ArrayList<ArrayList<Integer>>(14);
    
    
    public void configureWaits() {
        if (running) {
            String labelStr = "";
            for (Attraction a : rides) {
                a.setWaitTime();
                
                
            }
            
            

        }
    }
        
        /*
        This methods ensures that an individual hasn't been in the same location for the
        last 5 "passTime()"'s. If they have, they are told to respawn at the entrance to 
        the park
        */
        public void checkForRespawn() {
            for (Guest g: guests) {
                // If they aren't on a ride or in line and their last 500 locations have been the same, respawn...
                if (!g.inLine && !g.onRide && g.previousLocations.size() > 500) {
                    if (g.previousLocations.get(g.previousLocations.size() - 1) == g.previousLocations.get(g.previousLocations.size() - 100)) {
                        if (g.previousLocations.get(g.previousLocations.size() - 100) == g.previousLocations.get(g.previousLocations.size() - 200)) {
                            if (g.previousLocations.get(g.previousLocations.size() - 200) == g.previousLocations.get(g.previousLocations.size() - 300)) {
                                if (g.previousLocations.get(g.previousLocations.size() - 300) == g.previousLocations.get(g.previousLocations.size() - 500)) {
                                    // RESPAWN FUNCTION ...
                                    respawn(g);
                                }
                            }
                            
                        }
                    }
                }
            }
        }
        
        public void respawn(Guest g) {
            boolean foundRespawnLoc = false;
            int xCurr = 130;
            int yCurr = 830;
            while (!foundRespawnLoc) {
                
                
                if (!occupied[xCurr / 10][yCurr / 10]) {
                    g.setLocation(xCurr, yCurr);
                    foundRespawnLoc = true;
                } else {
                    xCurr += 10;
                }
                if (xCurr == 1280) {
                    xCurr = 130;
                    yCurr += 10;    
                }
                if (yCurr == 870) {
                    break;
                }
                
            }
            
//            if (!foundRespawnLoc) {
//                respawn(g);
//            }
        }
        
        
        
    public void updateLists() {
        DefaultListModel model = new DefaultListModel();
        for (Attraction a : rides) {
            model.addElement(a.toString());
        }
        shownList.setModel(model);
        
        shownTrackerList.setModel(trackingModel);
        
    }
        public void hideLabels() {
            labelsShowing = !labelsShowing;
        }
    
        /* 
        A method to take an individual from the ride (queue) and place them
        back on the map
        */
        public void rideExit(Attraction a) {
            if (a.ride.size() > 0) {
                  
                Guest g = (Guest)a.ride.peek();
                if (g.expTimer > a.expTime) {
                    g = (Guest) a.ride.remove();
                    g.ridesRidden.add(a);
                    g.expTimer = 0;
                    g.onRide = false;
                    g.setLocation((int)a.getExitPoint().getX(), (int)a.getExitPoint().getY());

                    g.previousLocations = new ArrayList<>();
                    if (g.tracking) {
                        trackingModel.addElement("Subject experienced " + a.name);
                    }
                    g.setHungerStatus(g.getHungerStatus() - 10);
                    g.setDestination(determineDestination(g));
                }
                
                
            }
        }
        
        /* takes individuals from a recently closed ride and the rides queue, 
        removing them to go somewhere else
        */
        public void rideEvac(Attraction a) {
            // Evacuate a guest from the ride
            if (a.ride.size() > 0) {

                    Guest g = (Guest) a.ride.remove();
                    g.expTimer = 0;
                    g.onRide = false;
                    g.setLocation((int)a.getExitPoint().getX(), (int)a.getExitPoint().getY());

                    g.previousLocations = new ArrayList<>();
                    if (g.tracking) {
                        trackingModel.addElement("Subject evacuated " + a.name);
                    }
                    g.setDestination(determineDestination(g));   
            }
            
            // Remove a guest from the line
            if (a.line.size() > 0) {
                Guest g = (Guest)a.line.remove();
                g.setLocation((int)a.getEarlyExitPoint().getX(), (int)a.getEarlyExitPoint().getY());
                g.inLine = false;
                g.onRide = false;
                g.previousLocations = new ArrayList<>();
                if (g.tracking) {
                    trackingModel.addElement("Subject exited the line for " + a.name);
                }
                g.setDestination(determineDestination(g));
                
            }
        }
        
        /*
        A method to take an individual from the line (queue) and put them in to the ride (queue)
        */
        public void rideLoad(Attraction a ) {
            if (a.line.size() > 0) {
                    
                Guest g = (Guest)a.line.remove();
                g.inLine = false;
                g.onRide = true;
                
                if (g.tracking) {
                    trackingModel.addElement("Subject was loaded onto " + a.name);
                }
                
                a.ride.add(g);
                // Starts the guests expierience timer
                g.expTimer = 0;
                
            }
        }
        public void save() {
            try {
                FileWriter writer = new FileWriter(saveFileLocation);
                for (int i = 0; i < horizontalSpaces; i++) {
                for (int j = 0; j < verticalSpaces; j++) {
                    if (fills[i][j]) {
                        writer.write(i + " " + j + " T\n");
                    } else {
                        writer.write(i + " " + j + " F\n");
                    }
                }
                }
                writer.close();
                System.out.println("Successfully wrote to the file.");
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }
        
        public void fill() {
            for (int i = 0; i < horizontalSpaces; i++) {
                for (int j = 0; j < verticalSpaces; j++) {
                    if (bools[i][j] == true) {
                        break;
                    } else {
                        fills[i][j] = true;
                        continue;
                    }
                
                }
            }
            panel.repaint();
            for (int i = horizontalSpaces - 1; i > 0; i--) {
                for (int j = verticalSpaces - 1; j > 0; j--) {
                    if (bools[i][j] == true) {
                        break;
                    } else {
                        fills[i][j] = true;
                        continue;
                    }
                
                }
            }
            panel.repaint();
            
            
            
            for (int i = 0; i < verticalSpaces; i++) {
                for (int j = 0; j < horizontalSpaces; j++) {
                    if (bools[j][i] == true) {
                        break;
                    } else {
                        fills[j][i] = true;
                        continue;
                    }
                
                }
            }
            panel.repaint();
            for (int i = verticalSpaces - 1; i > 0; i--) {
                for (int j = horizontalSpaces - 1; j > 0; j--) {
                    if (bools[j][i] == true) {
                        break;
                    } else {
                        fills[j][i] = true;
                        continue;
                    }
                
                }
            }
            panel.repaint();
            
            
        }
        
        public Attraction determineDestination(Guest g) {
//            if (g.getHungerStatus() < 0) {
//                for (Attraction f : restaurants) {
//                    return f;
//                }
//            }
            Attraction destination = rides.get(0);
            int minExhaust = Integer.MAX_VALUE;
            for (Attraction a : rides) {
                if (a.closed) {
                    continue;
                }
                int Exhaust = getExhaust(g, a);
                
                if (Exhaust < minExhaust) {
                    minExhaust = Exhaust;
                    destination = a;
                } 
                if (Exhaust == minExhaust) {
                    Random random = new Random();
                    boolean rand = random.nextBoolean();
                    if (rand) {
                        minExhaust = Exhaust;
                        destination = a;
                    }
                }
                
                
            }

            return destination;
        }
        
        public Attraction determineDestination (Guest g, Attraction excluded) {
            Attraction destination = rides.get(0);
            
            int minExhaust = Integer.MAX_VALUE;
            for (Attraction a : rides) {
                if (a == excluded || a.closed) {
                    continue;
                }
                int Exhaust = getExhaust(g, a);
                
                if (Exhaust < minExhaust) {
                    minExhaust = Exhaust;
                    destination = a;
                } 
                if (Exhaust == minExhaust) {
                    Random random = new Random();
                    boolean rand = random.nextBoolean();
                    if (rand) {
                        minExhaust = Exhaust;
                        destination = a;
                    }
                }
            }

            return destination;
            
        }
        
        public int getExhaust(Guest g, Attraction a) {
            int Exhaust = 0;
                // Exhaust from waiting
                Exhaust += a.totalWaitTime;
                
                // Exhaust from traveling
                int distance = (int)Point2D.distance(g.location.getX(), g.location.getY(), a.getAccessPoint().getX(), a.getAccessPoint().getY());
                Exhaust += (distance / 50);
                
                // excuse some Exhaust if the ride is age appropriate
                if (a.targetAudience.equalsIgnoreCase(g.age)) {
                    Exhaust -= 15;
                }
                if (g.ridesRidden.contains(a)) {
                    Exhaust += 50;
                }
                
                Exhaust -= (a.priority * 1.5);
                
            return Exhaust;
        }
        
        public void load() {
            try(Scanner fin = new Scanner(new File("Save.txt"))){
            if(fin.hasNextLine()) {
                while (fin.hasNextLine()) {
                    String curr = fin.nextLine();
                    String[] arr = curr.split(" ");
                    int i = Integer.parseInt(arr[0]);
                    int j = Integer.parseInt(arr[1]);
                    if (arr[2].equalsIgnoreCase("T")) {
                        bools[i][j] = true;
                        
                    } else {
                        bools[i][j] = false;
                        
                    }   
                }
                
                
                
               
                 
            }
            } catch (Exception e) {
                e.printStackTrace();
        }
        
            try(Scanner fin2 = new Scanner(new File("SaveFills.txt"))){
            if(fin2.hasNextLine()) {
                while (fin2.hasNextLine()) {
                    String curr = fin2.nextLine();
                    String[] arr = curr.split(" ");
                    int i = Integer.parseInt(arr[0]);
                    int j = Integer.parseInt(arr[1]);
                    if (arr[2].equalsIgnoreCase("T")) {
                        fills[i][j] = true;
                        
                    } else {
                        fills[i][j] = false;
                        
                    }   
                }
                
                
                
               
                 
            }
            
        } catch (Exception e) {
                e.printStackTrace();
        }
        }
    
        public static void main(String[] args) {
            MainFram mainfram = new MainFram();
        
    }
        
        public Guest earlyExit(Guest g) {
            
            g.setLocation(g.attractionDestination.getEarlyExitPoint());
            g.inLine = false;
            Attraction destination = determineDestination(g, g.attractionDestination);
            
            g.setDestination(destination);
            return g;
        }
        
        
        public void passTime() {
            
            // This indicates if an individual is already exiting this passTime()
            boolean oneExiting = false;
            
            
            // Priority of movement
            // Up, Down, Right, Left
            for (Guest g : guests) {
                
                // As guests move, they slowly get hungrier
                Random rand = new Random();
                boolean random = rand.nextBoolean();
                if (random) {
                    g.setHungerStatus(g.getHungerStatus() - 1);
                }
                
                if (g.inLine && !oneExiting) {
                    Attraction curr = g.attractionDestination;
                    for (Attraction a : rides) {
                        if (getExhaust(g, curr) - getExhaust(g, a) > 15 && !a.closed) {
                            
                            curr.line.remove(g);
                            g = earlyExit(g);
                            g.previousLocations = new ArrayList<>();
                            oneExiting = true;
                            break;
                            
                        }
                    }
                    
                }
                
                if (g.location.getX() == g.destination.getX() && g.location.getY() == g.destination.getY() && !g.inLine && !g.onRide) {
                    
                    if (g.attractionDestination.addToQueue(g)) {
                        g.inLine = true;
                        if (g.tracking) {
                            trackingModel.addElement("The subject began waiting in line for " + g.attractionDestination.name);    
                        }
                        int x = (int)g.location.getX();
                        int y = (int)g.location.getY();
                        occupied[x/10][y/10] = false;
                        
                    }
                    
                }
                if (!g.inLine && !g.onRide) {
                    // This indicates if g has moved or not this passTime()
                    boolean moved = false;
                    // Up
                    if (g.location.getY() > g.destination.getY()) {
                        int x = (int)g.location.getX();
                        int y = (int)g.location.getY() - 10;
                        if (x > 0 && y > 0) {
                            Point nextLocation = new Point(x, y);
                            if (/*!bools[x/10][y/10] &&*/ !occupied[x/10][y/10] && 
                                    !(g.previousLocations.contains(nextLocation))) {
                                g.setLocation(x, y);
                                occupied[x/10][y/10 + 1] = false;
                                occupied[x/10][y/10] = true;
                                moved = true;
                                g.previousLocations.add(nextLocation);

                            }
                        }
                    }
                    // Down
                    if (g.location.getY() < g.destination.getY() && !moved) {
                        int x = (int)g.location.getX();
                        int y = (int)g.location.getY() + 10;
                        if (x > 0 && y > 0) {
                            Point nextLocation = new Point(x, y);
                            if (/*!bools[x/10][y/10] &&*/ !occupied[x/10][y/10]
                                    && !(g.previousLocations.contains(nextLocation))) {
                                g.setLocation(x, y);
                                occupied[x/10][y/10 - 1] = false;
                                occupied[x/10][y/10] = true;
                                moved = true;
                                g.previousLocations.add(nextLocation);

                            }
                        }
                    }

                    // Left
                    if (g.location.getX() > g.destination.getX() && !moved) {
                        int x = (int)g.location.getX() - 10;
                        int y = (int)g.location.getY();
                        if (x > 0 && y > 0) {
                            Point nextLocation = new Point(x, y);
                            if (/*!bools[x/10][y/10] &&*/ !occupied[x/10][y/10]
                                    && !(g.previousLocations.contains(nextLocation))){
                                g.setLocation(x, y);
                                occupied[x/10 + 1][y/10] = false;
                                occupied[x/10][y/10] = true;
                                moved = true;
                                g.previousLocations.add(nextLocation);

                            }
                        }

                    } 
                    // Right
                    if (g.location.getX() < g.destination.getX() && !moved) {
                        int x = (int)g.location.getX() + 10;
                        int y = (int)g.location.getY();
                        if (x > 0 && y > 0) {
                        
                            Point nextLocation = new Point(x, y);
                            if (/*!bools[x/10][y/10] &&*/ !occupied[x/10][y/10]
                                    && !(g.previousLocations.contains(nextLocation))) {
                                g.setLocation(x, y);
                                occupied[x/10 - 1][y/10] = false;
                                occupied[x/10][y/10] = true;
                                moved = true;
                                g.previousLocations.add(nextLocation);

                            }
                        }

                    }
                    
                    /*if (!moved) {
                        g.previousLocations.add(g.location);
                    }*/
                    
                    if (currentTime[0] >= 20) {
                        endSim();
                    }
                    
                    

                
                    panel.repaint();
                }
            
            }
        }
        
        public void endSim() {
            simEnded = true;
            simSkip.setVisible(true);
            printReportButton.setVisible(true);
        }
        
        public boolean simEnded = false;
    
    class myPanel extends JPanel {

        
        public myPanel() {
            setVisible(true);
            addMouseListener(new MouseAdapter() { 
                public void mousePressed(MouseEvent me) { 
                    int xPress = me.getX();
                    int yPress = me.getY();
                    while (xPress % blockSize != 0) {
                        xPress--;
                    }
                    while (yPress % blockSize != 0 ) {
                        yPress--;
                    }
                    int i = xPress/blockSize;
                    int j = yPress/blockSize;
                    
                    //bools[i][j] = true;
                    System.out.println(xPress + " " + yPress);
                    for (Guest g : guests) {
                        if (g.location.getX() == xPress && g.location.getY() == yPress) {
                            
                            for (Guest x : guests) {
                                x.tracking = false;
                            }
                            g.tracking = true;
                            ageLabel.setText("The age group of the subject is " + g.age);
                            trackingModel = new DefaultListModel();
                        }
                    }
                        
                    
                } 
            });
            
            this.addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseDragged(MouseEvent e) {
                    int xPress = e.getX();
                    int yPress = e.getY();
                    while (xPress % blockSize != 0) {
                        xPress--;
                    }
                    while (yPress % blockSize != 0 ) {
                        yPress--;
                    }
                    int i = xPress/blockSize;
                    int j = yPress/blockSize;
                    
                    //fills[i][j] = true;
                    
                     
                    
                    
                    repaint();
                }
            });
    }
            
            
            
            
        
        @Override
        public void paintComponent(Graphics g) {
           
           super.paintComponent(g);
           if (!simEnded) {
           g.setColor(Color.BLACK);
           for (int i = 0; i < horizontalSpaces; i++) {
                for (int j = 0; j < verticalSpaces; j++) {
                    g.setColor(Color.BLACK);
                    //g.drawRect((int)spaces[i][j].getX(), (int)spaces[i][j].getY(), blockSize, blockSize);
                    if (bools[i][j]) {
                        g.setColor(new Color(125, 112, 186));
                        g.fillRect((int)spaces[i][j].getX(), (int)spaces[i][j].getY(), blockSize, blockSize);    
                    }
                    
                }
                    
            }
           
           for (int r = 0; r < horizontalSpaces; r++) {
                for (int m = 0; m < verticalSpaces; m++) {
                    if (fills[r][m]) {
                        
                        if (loc < 0) {
                            loc = 0;
                        }
                        if (backColors.size() > 0) {
                            g.setColor(backColors.get(loc));
                            g.fillRect((int)spaces[r][m].getX(), (int)spaces[r][m].getY(), blockSize, blockSize);     
                        }
                         
                    }
                }
            }
           
           // Paint Castle
           g.setColor(Color.pink);
           g.fillRect(670, 250, 140, 60);
           g.fillRect(698, 205, 84, 45);
           g.fillRect(740, 175, 42, 30);
           
           g.setColor(Color.black);
           g.fillRect(720, 280, 40, 30);
           g.fillOval(720, 260, 40, 40);
           
           g.setColor(Color.blue);
           //g.fillPolygon(xPoints, yPoints, WIDTH);
            for (Attraction a : rides) {
                
                
                Point p = a.getAccessPoint();
                int xPress = (int)p.getX();
                int yPress = (int)p.getY();
                    while (xPress % blockSize != 0) {
                        xPress--;
                    }
                    while (yPress % blockSize != 0 ) {
                        yPress--;
                    }
                
                
                
                Point p2 = a.getExitPoint();
                int xPress2 = (int)p2.getX();
                int yPress2 = (int)p2.getY();
                while (xPress2 % blockSize != 0) {
                    xPress2--;
                }
                while (yPress2 % blockSize != 0 ) {
                    yPress2--;
                }
                
                Point p3 = a.earlyExitPoint;
                int xPress3 = (int)p3.getX();
                int yPress3 = (int)p3.getY();
                while (xPress3 % blockSize != 0) {
                    xPress3--;
                }
                while (yPress3 % blockSize != 0 ) {
                    yPress3--;
                }
                
                g.setColor(Color.white);
                g.fillRect(xPress, yPress, 60, 60);
                if (!labelsShowing) {
                    g.setColor(Color.black);
                    g.drawRect(xPress, yPress, 60, 60);
                }
                
                
                if (labelsShowing) {
                    a.draw(g);    
                }
                
                
                g.setColor(Color.red);
                g.fillRect(xPress, yPress, blockSize, blockSize);   
                g.setColor(Color.yellow);
                g.fillRect(xPress2, yPress2, blockSize, blockSize);
                g.setColor(Color.lightGray);
                g.fillRect(xPress3, yPress3, blockSize, blockSize);
                
            }
            
            for (Attraction r : restaurants) {
                r.draw(g);
            }
            
            //leaving.draw(g);
            
            for (Guest t : guests) {
                if (!t.inLine && !t.onRide) {
                    t.draw(g);   
                }
            }
            
            
            // Draw the time bar for the sun/moon going across the bar to indicate the time
            Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
            g.setColor(Color.BLACK);
            g.fillRect(0, 800, dim.width, 50);
            colors = new int[5][3];
            setSunColors();
            int divisions = dim.width / 5;
            int colorChangeInv = divisions / 5;
            int currInvCounter = 0;
            int x = 0;
            int y = 800;
            int[] currColor = {colors[0][0], colors[0][1], colors[0][2]};
            int hourCoverage = 15;
            int hourChangeInv = divisions / hourCoverage;
            int currHour = 7;

            for (int i = 0; i < divisions; i++) {
                for (int j = 0; j < 3; j++) {
                    if (currColor[j] > 255) {
                        currColor[j] = 255;
                    }
                    if (currColor[j] < 0) {
                        currColor[j] =0;
                    }
                }
                Color color = new Color(currColor[0], currColor[1], currColor[2]);
                
                if (currInvCounter < colorChangeInv ) {
                currColor[0] = ((colors[1][0] - colors[0][0]) / colorChangeInv) + currColor[0];
                currColor[1] =((colors[1][1] - colors[0][1]) / colorChangeInv) + currColor[1];
                currColor[2] =  ((colors[1][2] - colors[0][2]) / colorChangeInv) + currColor[2];   
                } else if (currInvCounter < (2*colorChangeInv)) {
                currColor[0] = ((colors[2][0] - colors[1][0]) / colorChangeInv) + currColor[0];
                currColor[1] =((colors[2][1] - colors[1][1]) / colorChangeInv) + currColor[1];
                currColor[2] =  ((colors[2][2] - colors[1][2]) / colorChangeInv) + currColor[2];   
                } else if (currInvCounter < (3*colorChangeInv)) {
                currColor[0] = ((colors[3][0] - colors[2][0]) / colorChangeInv) + currColor[0];
                currColor[1] =((colors[3][1] - colors[2][1]) / colorChangeInv) + currColor[1];
                currColor[2] =  ((colors[3][2] - colors[2][2]) / colorChangeInv) + currColor[2];       
                } else if (currInvCounter < (4*colorChangeInv)) {
                currColor[0] = ((colors[4][0] - colors[3][0]) / colorChangeInv) + currColor[0];
                currColor[1] =((colors[4][1] - colors[3][1]) / colorChangeInv) + currColor[1];
                currColor[2] =  ((colors[4][2] - colors[3][2]) / colorChangeInv) + currColor[2]; 
                }
                
                
                if (currInvCounter % hourChangeInv == 0) {
                    g.setColor(Color.black);
                    if (currHour == 13) {
                        currHour = 1;
                    }
                    g.drawString("" + currHour, x, y);
                    currHour++;
                }
                currInvCounter++;
                
                backColors.add(color);
                g.setColor(color);
                
                
                
                
                
                
                
                
                g.fillRect(x, y, 5, 50);
                x += 5;
 
            }
            
            
            
            
            
            
            
            int hoursWorthDistance = 112;
            double distance = 0;
            distance = ((double)hoursWorthDistance * ((double)dailySecondsSurpassed / 3600)) - ((double)7 * hoursWorthDistance);
          
            
            // Draw the sun/ mooon
            if (distance < hoursWorthDistance * 11) {
                g.setColor(Color.yellow);
                g.fillOval((int)distance - 25 , 800, 50, 50);    
            } else {
                g.setColor(Color.cyan);
                g.fillOval((int)distance - 25 , 800, 50, 50);  
            }
            loc = (int)distance - 25;
            loc = loc / 5;
            
            // DOES NOT WORK
            for (Attraction a: rides) {
                if (a.closed) {
                    g.setColor(Color.red);
                    float f=40.0f; // font size.
                    g.setFont(g.getFont().deriveFont(f));
                    g.drawString(("X"), x , y + 10);
                }
            }
            
            
            
           } else {
               simEndedArea.setVisible(true);
               this.setBackground(Color.black);
               this.setOpaque(true);
               newDayButton.setVisible(true);
           }
            
            

                       
           

        }
        public int[][] colors;
        public ArrayList<Color> backColors = new ArrayList<>();
        
        public void setSunColors() {
            // sunrise
            colors[0][0] = 181;
            colors[0][1] = 214;
            colors[0][2] = 224;
            
            // Morning sun
            colors[1][0] = 255;
            colors[1][1] = 239;
            colors[1][2] = 122; 
            
            // noon sun
            colors[2][0] = 247;
            colors[2][1] = 193;
            colors[2][2] = 106;
            
            // Evening sun
            colors[3][0] = 255;
            colors[3][1] = 107;
            colors[3][2] = 62;
            
            // sunset
            colors[4][0] = 39;
            colors[4][1] = 33;
            colors[4][2] = 78;
        }

}
    



    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        statsPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        shownList = new javax.swing.JList<>();
        ageLabel = new javax.swing.JLabel();
        shownPanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        simEndedArea = new javax.swing.JTextArea();
        newDayButton = new javax.swing.JButton();
        printReportButton = new javax.swing.JButton();
        reportLoc = new javax.swing.JTextField();
        logPanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        shownTrackerList = new javax.swing.JList<>();
        jPanel1 = new javax.swing.JPanel();
        shownTimeLabel = new javax.swing.JLabel();
        pauseButton = new javax.swing.JButton();
        skipHourButton = new javax.swing.JButton();
        labelButton = new javax.swing.JButton();
        simSkip = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        shownList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(shownList);

        ageLabel.setFont(new java.awt.Font("Tahoma", 1, 8)); // NOI18N
        ageLabel.setText("ageLabel");

        javax.swing.GroupLayout statsPanelLayout = new javax.swing.GroupLayout(statsPanel);
        statsPanel.setLayout(statsPanelLayout);
        statsPanelLayout.setHorizontalGroup(
            statsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statsPanelLayout.createSequentialGroup()
                .addGroup(statsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 199, Short.MAX_VALUE)
                    .addComponent(ageLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 22, Short.MAX_VALUE))
        );
        statsPanelLayout.setVerticalGroup(
            statsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addComponent(ageLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        shownPanel = panel;

        simEndedArea.setColumns(20);
        simEndedArea.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        simEndedArea.setLineWrap(true);
        simEndedArea.setRows(5);
        simEndedArea.setText("The simulation has ended. The stats can be viewed on the right. If you would like to start a new day, click the button below.");
        simEndedArea.setWrapStyleWord(true);
        jScrollPane3.setViewportView(simEndedArea);

        newDayButton.setText("Start a new day");
        newDayButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newDayButtonActionPerformed(evt);
            }
        });

        printReportButton.setText("Print Report");
        printReportButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printReportButtonActionPerformed(evt);
            }
        });

        reportLoc.setText("Type Destination for Printed Report here before pressing");

        javax.swing.GroupLayout shownPanelLayout = new javax.swing.GroupLayout(shownPanel);
        shownPanel.setLayout(shownPanelLayout);
        shownPanelLayout.setHorizontalGroup(
            shownPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(shownPanelLayout.createSequentialGroup()
                .addGap(306, 306, 306)
                .addGroup(shownPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, shownPanelLayout.createSequentialGroup()
                        .addComponent(reportLoc, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(printReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(newDayButton, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 793, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(357, Short.MAX_VALUE))
        );
        shownPanelLayout.setVerticalGroup(
            shownPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(shownPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(shownPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newDayButton)
                    .addComponent(reportLoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(printReportButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        shownTrackerList.setFont(new java.awt.Font("Tahoma", 1, 8)); // NOI18N
        shownTrackerList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(shownTrackerList);

        javax.swing.GroupLayout logPanelLayout = new javax.swing.GroupLayout(logPanel);
        logPanel.setLayout(logPanelLayout);
        logPanelLayout.setHorizontalGroup(
            logPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
                .addContainerGap())
        );
        logPanelLayout.setVerticalGroup(
            logPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(logPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 283, Short.MAX_VALUE)
                .addContainerGap())
        );

        shownTimeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        shownTimeLabel.setText("timeLabel");

        pauseButton.setText("||");

        skipHourButton.setText("Skip an Hour");
        skipHourButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                skipHourButtonActionPerformed(evt);
            }
        });

        labelButton.setText("Hide Labels");
        labelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                labelButtonActionPerformed(evt);
            }
        });

        simSkip.setText("Skip the Sim");
        simSkip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simSkipActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(shownTimeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(pauseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(83, 83, 83))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(labelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(simSkip, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(skipHourButton, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(shownTimeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pauseButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(skipHourButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(simSkip)
                .addGap(11, 11, 11)
                .addComponent(labelButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(shownPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(logPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(statsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(statsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(logPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(shownPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public int loc = 0;
    private void skipHourButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_skipHourButtonActionPerformed
        int counter = 0;

        
        while (counter < 7200000) {

            if (counter % 100 == 0) {
                
                //tmrTask
                passTime();
            
                // destinationReorientation
                /*for (Guest g : guests) {
                    g.setDestination(determineDestination(g));
                }*/
                
                //unloadClosedRides
                for (Attraction a : rides) {
                    if (a.closed) {
                        rideEvac(a);     
                    }       
                }
    
            }
            
            for (Attraction a: rides) {
                if (counter % a.outFlowTime == 0) {
                    rideExit(a);
                    rideLoad(a);
                }
            }
            
            if (counter % 2000 == 0) { 
                //updateWaitTimes
                configureWaits();
                
                updateLists(); 
                dailySecondsSurpassed += 1;
                // Gives hours
                currentTime[0] = dailySecondsSurpassed / 3600;
                // Gives minutes
                currentTime[1] = (dailySecondsSurpassed % 3600) / 60;
                // Gives seconds
                currentTime[2] = (dailySecondsSurpassed - (currentTime[0] * 3600) - (currentTime[1] * 60));
                shownTimeLabel.setText(currentTime[0] + ":" + currentTime[1] + ":" + currentTime[2]);
                if (currentTime[1] == 0 && currentTime[2] == 0) {
                    createEntry(currentTime[0]);
                }
                panel.repaint();
            }
            
            if (counter % 12000 == 0) {
                //OneTenthMinutePasses
                for (Guest g : guests) {
                    if (g.onRide) {
                        g.expTimer += 0.1;     
                    }  
                    
                }
            }
            
            if (counter % 360000 == 0) {
                //ThreeMinutesPasses
                for (Guest g: guests) {
                    boolean marathon = true;
                    for (Attraction a: rides) {
                        if (!g.ridesRidden.contains(a)) {
                            marathon = false;
                        }
                     }
                    if (marathon) {
                        g.ridesRidden = new ArrayList<>();
                    }
                    
                }
                
                
            }
            
            if (counter % 10000 == 0) {
                //FiveSecondsPasses
                //checkForRespawn();
            }


            
            
            
            
            counter++;
        }
        
      

    }//GEN-LAST:event_skipHourButtonActionPerformed

    private void newDayButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newDayButtonActionPerformed
        MainFram mf = new MainFram();
        this.dispose();
        mf.show();
        
    }//GEN-LAST:event_newDayButtonActionPerformed

    private void labelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_labelButtonActionPerformed
        hideLabels();
    }//GEN-LAST:event_labelButtonActionPerformed

    private void simSkipActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simSkipActionPerformed
        int counter = 0;

        
        while (counter < 28800000) {

            if (counter % 50 == 0) {
                
                //tmrTask
                passTime();
            
                // destinationReorientation
                /*for (Guest g : guests) {
                    g.setDestination(determineDestination(g));
                }*/
                
                //unloadClosedRides
                for (Attraction a : rides) {
                    if (a.closed) {
                        rideEvac(a);     
                    }       
                }
    
            }
            
            for (Attraction a: rides) {
                if (counter % a.outFlowTime/2 == 0) {
                    rideExit(a);
                    rideLoad(a);
                }
            }
            
            if (counter % 1000 == 0) { 
                //updateWaitTimes
                configureWaits();
                
                updateLists(); 
                dailySecondsSurpassed += 1;
                // Gives hours
                currentTime[0] = dailySecondsSurpassed / 3600;
                // Gives minutes
                currentTime[1] = (dailySecondsSurpassed % 3600) / 60;
                // Gives seconds
                currentTime[2] = (dailySecondsSurpassed - (currentTime[0] * 3600) - (currentTime[1] * 60));
                shownTimeLabel.setText(currentTime[0] + ":" + currentTime[1] + ":" + currentTime[2]);
                if (currentTime[1] == 0 && currentTime[2] == 0) {
                    createEntry(currentTime[0]);
                }
                panel.repaint();
            }
            
            if (counter % 6000 == 0) {
                //OneTenthMinutePasses
                for (Guest g : guests) {
                    if (g.onRide) {
                        g.expTimer += 0.1;     
                    }  
                    
                }
            }
            
            if (counter % 180000 == 0) {
                //ThreeMinutesPasses
                for (Guest g: guests) {
                    boolean marathon = true;
                    for (Attraction a: rides) {
                        if (!g.ridesRidden.contains(a)) {
                            marathon = false;
                        }
                     }
                    if (marathon) {
                        g.ridesRidden = new ArrayList<>();
                    }
                    
                }
                
                
            }
            
            if (counter % 5000 == 0) {
                //FiveSecondsPasses
                //checkForRespawn();
            }


            
            
            
            
            counter++;
        }
    }//GEN-LAST:event_simSkipActionPerformed
 
    private void printReportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printReportButtonActionPerformed
        try {
            //
            FileWriter myWriter = new FileWriter(reportLoc.getText());
            //
            myWriter.write("Time     ");
            for (Attraction a: rides) {
                String printString = a.name;
                printString = printString.substring(0, 5) + ".";
                while (printString.length() < 9) {
                    printString += " ";
                }
                myWriter.write(printString);
            }
            myWriter.write("\n");
            for (ArrayList<Integer> list : entries) {
                
                for (Integer i: list) {
                    String str = "" + i;
                    while (str.length() < 9) {
                        str += " ";
                    }
                    myWriter.write(str);
                }
                myWriter.write("\n");
            }
            
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
            JOptionPane.showMessageDialog(null, "Saved","Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Cannot Find Valid File Location","ERROR", JOptionPane.ERROR_MESSAGE);
        } 
    }//GEN-LAST:event_printReportButtonActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ageLabel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JButton labelButton;
    private javax.swing.JPanel logPanel;
    private javax.swing.JButton newDayButton;
    private javax.swing.JButton pauseButton;
    private javax.swing.JButton printReportButton;
    private javax.swing.JTextField reportLoc;
    private javax.swing.JList<String> shownList;
    private javax.swing.JPanel shownPanel;
    private javax.swing.JLabel shownTimeLabel;
    private javax.swing.JList<String> shownTrackerList;
    private javax.swing.JTextArea simEndedArea;
    private javax.swing.JButton simSkip;
    private javax.swing.JButton skipHourButton;
    private javax.swing.JPanel statsPanel;
    // End of variables declaration//GEN-END:variables

}