
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JToggleButton;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author blake
 */
public class MainFrame implements KeyListener{
    public JFrame frame;

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == 16) {
            shiftPressed = true;
        }
    }
    public JPanel panel;
    
    public int dailySecondsSurpassed = 0;
    public Integer[] currentTime = new Integer[3];
    public JLabel timeLabel = new JLabel();
    
    public int horizontalSpaces;
    public int verticalSpaces;
    public Rectangle[][] spaces;
    public Boolean[][] bools;
    public Boolean[][] fills;
    public Boolean[][] occupied;
    public int blockSize;
    public double xSize;
    public double ySize;
    public boolean shiftPressed;
    int shifti = -1;
    int shiftj = -1;
    //public Attraction leaving;
    
    public boolean labelsShowing = true;
    
    public ArrayList<Attraction> rides = new ArrayList<>();
    public ArrayList<Attraction> restaurants = new ArrayList<>();
            
    public ArrayList<Guest> guests = new ArrayList<>();
    
    public JList list = new JList();
    public JList trackingList = new JList();
    public DefaultListModel trackingModel = new DefaultListModel();
    
    public boolean running = true;
    
    public Timer tmr = new Timer();
    
    public JFrame statsFrame;
    public JFrame trackingFrame;
    public boolean statsShowing = false;
    public boolean trackingShowing = false;
    
    
    public MainFrame()  {
        
        
        

        
        Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        
        
        blockSize = 10;
        size = Toolkit.getDefaultToolkit().getScreenSize();
        xSize = size.getWidth();
        ySize = size.getHeight();
        horizontalSpaces = (int) xSize / blockSize;
        
        verticalSpaces = (int) ySize / blockSize;
        
        spaces = new Rectangle[horizontalSpaces][verticalSpaces];
        bools = new Boolean[horizontalSpaces][verticalSpaces];
        fills = new Boolean[horizontalSpaces][verticalSpaces];
        occupied = new Boolean[horizontalSpaces][verticalSpaces];
        
        
        int currx = 0;
        int curry = 0;
        for (int i = 0; i < horizontalSpaces; i++) {
            for (int j = 0; j < verticalSpaces; j++) {
                Point p = new Point(currx, curry);
                
                curry += blockSize;
                Dimension d = new Dimension(blockSize, blockSize);
                spaces[i][j] = new Rectangle(p, d);
                bools[i][j] = false;
                fills[i][j] = false;
                occupied[i][j] = false;
                
            }
            currx += blockSize;  
            curry = 0;
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        load();
        
        // ADD THE rides 
        //(0)
        Attraction hauntedMansion = new Attraction("Haunted Mansion", 1500, 1000, "Adult", 7.5);
        hauntedMansion.setGraphics(250, 160, 200, 100, Color.magenta);
        rides.add(hauntedMansion);
        
        //(1)
        Attraction spaceMountain = new Attraction("Space Mountain", 1800, 1000, "Young Adult", 2.5);
        spaceMountain.setGraphics(1290, 370, 200, 100, Color.white);
        rides.add(spaceMountain);
        
        //(2)
        Attraction splashMountain = new Attraction("Splash Mountain", 2000, 1000, "Young Adult", 11);
        splashMountain.setGraphics(30, 300, 100, 70, Color.cyan);
        rides.add(splashMountain);
        
        //(3)
        Attraction dumbo = new Attraction("Dumbo", 3000, 1000, "Child", 1.5);
        dumbo.setGraphics(1200, 150, 100, 100, Color.gray);
        rides.add(dumbo);
        
        //(4)
        Attraction mermaid = new Attraction("The Little Mermaid", 2000, 1000, "Child", 6.25);
        mermaid.setGraphics(1010, 130, 200, 50, Color.orange);
        rides.add(mermaid);
        
        //(5)
        Attraction peopleMover = new Attraction("The People Mover", 1000, 1000, "Adult", 10.1);
        peopleMover.setGraphics(1100, 460, 200, 50, Color.gray);
        rides.add(peopleMover);
        
        // (6)
        Attraction pooh = new Attraction("Winnie the Pooh", 4500, 1000, "Child", 3.1);
        pooh.setGraphics(920, 240, 200, 50, Color.yellow);
        rides.add(pooh);
        
        
        
//         leaving = new Attraction("EXIT", 10, 10000, "All");
//        leaving.setGraphics(600, 800, 50, 50, Color.pink);
        
        
        
         //ADD THE Initial GUESTS
        for (int x = 130; x <= 1280; x += 10) {
            for (int y = 830; y <= 870; y += 10) {
                Random random = new Random();
                int rand = random.nextInt(3);
                Guest guest = new Guest("Adult");
                switch (rand) {
                    case 0:
                        guest = new Guest("Child");
                        break;
                    case 1:
                        guest = new Guest("Adult");
                        break;
                    case 2:
                        guest = new Guest("Young Adult");
                        break;
                    default:
                        break;
                }
                guest.setLocation(x, y);
                guest.setDestination(determineDestination(guest));
                
                guests.add(guest);
                occupied[x/10][y/10] = true;
                
                
            }
        }
        Guest guest = new Guest("Adult");
        guest.setLocation(100, 830);
        guest.tracking = true;
        guest.setDestination(dumbo);
        guests.add(guest);
        occupied[10][83] = true;
        
        ArrayList<TimerTask> peopleAdder = new ArrayList<>();
        int delay = 0;
        for (int i = 0; i < 5; i ++) {
            delay += 20000;
            
            TimerTask addMoreGuests = new TimerTask() {
                @Override
                public void run() {
                    for (int x = 130; x <= 1280; x += 10) {
                        for (int y = 830; y <= 870; y += 10) {
                            Random random = new Random();
                            int rand = random.nextInt(3);
                            Guest guest = new Guest("Adult");
                            switch (rand) {
                                case 0:
                                    guest = new Guest("Child");
                                    break;
                                case 1:
                                    guest = new Guest("Adult");
                                    break;
                                case 2:
                                    guest = new Guest("Young Adult");
                                    break;
                                default:
                                    break;
                            }
                            guest.setLocation(x, y);
                            guest.setDestination(determineDestination(guest));

                            guests.add(guest);
                            occupied[x/10][y/10] = true;    
                        }
                    }

                }
            }; 
            peopleAdder.add(addMoreGuests);
            tmr.schedule(addMoreGuests, delay);
        }
        
        
        tmr = new Timer();
        
        TimerTask tmrTask = new TimerTask() {
            @Override
            public void run() {
                if (running) {
                    passTime();    
                } else {
                    panel.repaint();
                }
                
            }
        };
        
        TimerTask updateWaitTimes = new TimerTask() {
            @Override
            public void run() {
                if (running) {
                    for (Attraction a : rides) {
                        a.setWaitTime();
                    }
                    panel.repaint();
                    updateLists(); 
                    dailySecondsSurpassed += 1;
                    // Gives hours
                    currentTime[0] = dailySecondsSurpassed / 3600;
                    // Gives minutes
                    currentTime[1] = (dailySecondsSurpassed % 3600) / 60;
                    // Gives seconds
                    currentTime[2] = (dailySecondsSurpassed - (currentTime[0] * 3600) - (currentTime[1] * 60));
                    timeLabel.setText("The amount of time passed is " + currentTime[0] + ":" + currentTime[1] + ":" + currentTime[2]);
                    
                }
                
            }
        };
        
        // Creates and Loads TimerTasks to transfer people on and off rides at
        // the specified time interval (outFlowTime) for each ride
        ArrayList<TimerTask> rideTransfers = new ArrayList<>();
        for (Attraction a : rides) {
            TimerTask newTask = new TimerTask() {
                @Override
                public void run() {
                    if (running) {
                        // By exiting the ride first, we ensure that a person doesnt get on the ride 
                        // and then exit it immediately
                        rideExit(a);
                        rideLoad(a);    
                    }
                    
                }
            };
            rideTransfers.add(newTask);
            // The task is called at half the outflowtime so that
            // the time for one individual to get on and off the ride
            // is equal to the outFlowTime (oft / 2) * 2 = oft;
            
            tmr.schedule(newTask, 0, a.outFlowTime / 2);
        }
        
        JButton pause = new JButton("Pause / Play");
        pause.setBounds(500, 500, 50, 50);
        pause.addActionListener((e) -> {
            running = !running;
        });
        
        
        
        JFrame  buttonsFrame= new JFrame();
        JPanel buttonsPanel = new JPanel();
        buttonsFrame.setAlwaysOnTop(true);
        buttonsFrame.setSize(200, 200);
        
        statsFrame = new JFrame();
        JPanel statsPanel = new JPanel();
        statsFrame.setAlwaysOnTop(true);
        statsFrame.add(statsPanel);
        statsPanel.add(list);
        
        trackingFrame = new JFrame();
        JPanel trackingPanel = new JPanel();
        trackingFrame.setAlwaysOnTop(true);
        trackingFrame.add(trackingPanel);
        trackingFrame.add(trackingList);
        
        trackingFrame.setSize(500, 500);
        statsFrame.setSize(500, 500);
        
        frame = new JFrame("Grid");
        panel = new myPanel();
        
        
        JButton button = new JButton("Save");
        button.setBounds(0, 0, 50, 50);
        button.addActionListener((e) -> {
            //save();
        });
        
        JButton button2 = new JButton("Fill");
        button2.setBounds(100, 100, 50, 50);
        button2.addActionListener((e) -> {
            fill();
        });
        
        JButton labelHider = new JButton("HideLabels");
        labelHider.setBounds(200, 200, 50, 50);
        labelHider.addActionListener((e) -> {
            hideLabels();
        });
        
        JButton stats = new JButton("Stats");
        stats.setBounds(300, 300, 50, 50);
        stats.addActionListener((e) -> {
            statsFrame.setVisible(!statsShowing);
            statsShowing = !statsShowing;
        });
        
        JButton tracker = new JButton("Tracker");
        tracker.setBounds(400, 400, 50, 50);
        tracker.addActionListener((e) -> {
            trackingFrame.setVisible(!trackingShowing);
            trackingShowing = !trackingShowing;
        });
        
        
        buttonsPanel.add(button);
        buttonsPanel.add(button2);
        buttonsPanel.add(labelHider);
        buttonsPanel.add(tracker);
        buttonsPanel.add(stats);
        buttonsPanel.add(pause);
        
        frame.add(panel);
        frame.setSize(size);
        frame.show(); 
        buttonsFrame.add(buttonsPanel);
        buttonsFrame.show();
        
     
        
        
        
        tmr.schedule(tmrTask, 0, 50);
        tmr.schedule(updateWaitTimes, 0, 1000);
        
             
        
        // Every 60,000 milliseconds, a minute passes
        TimerTask oneTenthMinutePassed = new TimerTask() {
            @Override
            public void run() {
                for (Guest g : guests) {
                    
                    if (g.onRide) {
                        g.expTimer += 0.1;   
                        
                    }  
                    
                }
                
            }
                
        };
        tmr.schedule(oneTenthMinutePassed, 0, 6000);
        
        

        DefaultListModel model = new DefaultListModel();
            for (Attraction a : rides) {
                model.addElement(a.toString());
            }
            list = new JList(model);
            list.setLocation(900, 0);
            panel.add(list);
            list.setVisible(true);
 
            
        
        trackingList.setModel(trackingModel);
        trackingList.setLocation(900, 900);
        panel.add(trackingList);
        trackingList.setVisible(true);
        
        timeLabel = new JLabel("The current time is " + currentTime[0] + ":" + currentTime[1] + ":" + currentTime[2]);
        timeLabel.setBounds(0, 0, 100, 100);
        timeLabel.setBackground(Color.green);
        panel.add(timeLabel);
        
        
        for (Attraction a : rides) {
            JToggleButton closedButton = new JToggleButton("X");
            closedButton.setSelected(false);
            closedButton.addActionListener((e) -> {
                if (closedButton.isSelected()) {
                    a.closed = true;
                } else {
                    a.closed = false;
                }
            });
            
            
        }
        
        
        
    }
    
        
    public void updateLists() {
        DefaultListModel model = new DefaultListModel();
        for (Attraction a : rides) {
            model.addElement(a.toString());
        }
        list.setModel(model);
        
        trackingList.setModel(trackingModel);
        
    }
        public void hideLabels() {
            labelsShowing = !labelsShowing;
        }
    
        /* 
        A method to take an individual from the ride (queue) and place them
        back on the map
        */
        public void rideExit(Attraction a) {
            if (a.ride.size() > 0) {
                  
                Guest g = (Guest)a.ride.peek();
                if (g.expTimer > a.expTime) {
                    g = (Guest) a.ride.remove();
                    g.ridesRiden.add(a);
                    g.expTimer = 0;
                    g.onRide = false;
                    g.setLocation((int)a.getExitPoint().getX(), (int)a.getExitPoint().getY());

                    g.previousLocations = new ArrayList<>();
                    if (g.tracking) {
                        trackingModel.addElement("Subject experienced " + a.name);
                    }
                    g.setHungerStatus(g.getHungerStatus() - 10);
                    g.setDestination(determineDestination(g));
                }
                
                
            }
        }
        /*
        A method to take an individual from the line (queue) and put them in to the ride (queue)
        */
        public void rideLoad(Attraction a ) {
            if (a.line.size() > 0) {
                    
                Guest g = (Guest)a.line.remove();
                g.inLine = false;
                g.onRide = true;
                
                if (g.tracking) {
                    trackingModel.addElement("Subject was loaded onto " + a.name);
                }
                
                a.ride.add(g);
                // Starts the guests expierience timer
                g.expTimer = 0;
                
            }
        }
        public void save() {
            try {
                FileWriter writer = new FileWriter("C:\\Users\\blake\\Desktop\\WaitPlease\\Save.txt");
                for (int i = 0; i < horizontalSpaces; i++) {
                for (int j = 0; j < verticalSpaces; j++) {
                    if (bools[i][j]) {
                        writer.write(i + " " + j + " T\n");
                    } else {
                        writer.write(i + " " + j + " F\n");
                    }
                }
                }
                writer.close();
                System.out.println("Successfully wrote to the file.");
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }
        
        public void fill() {
            for (int i = 0; i < horizontalSpaces; i++) {
                for (int j = 0; j < verticalSpaces; j++) {
                    if (bools[i][j] == true) {
                        break;
                    } else {
                        fills[i][j] = true;
                        continue;
                    }
                
                }
            }
            panel.repaint();
            for (int i = horizontalSpaces - 1; i > 0; i--) {
                for (int j = verticalSpaces - 1; j > 0; j--) {
                    if (bools[i][j] == true) {
                        break;
                    } else {
                        fills[i][j] = true;
                        continue;
                    }
                
                }
            }
            panel.repaint();
            
            
            
            for (int i = 0; i < verticalSpaces; i++) {
                for (int j = 0; j < horizontalSpaces; j++) {
                    if (bools[j][i] == true) {
                        break;
                    } else {
                        fills[j][i] = true;
                        continue;
                    }
                
                }
            }
            panel.repaint();
            for (int i = verticalSpaces - 1; i > 0; i--) {
                for (int j = horizontalSpaces - 1; j > 0; j--) {
                    if (bools[j][i] == true) {
                        break;
                    } else {
                        fills[j][i] = true;
                        continue;
                    }
                
                }
            }
            panel.repaint();
            
            
        }
        
        public Attraction determineDestination(Guest g) {
//            if (g.getHungerStatus() < 0) {
//                for (Attraction f : restaurants) {
//                    return f;
//                }
//            }
            Attraction destination = rides.get(0);
            int minExaust = Integer.MAX_VALUE;
            for (Attraction a : rides) {
                if (g.ridesRiden.contains(a) || a.closed) {
                    continue;
                }
                int exaust = getExaust(g, a);
                
                if (exaust < minExaust) {
                    minExaust = exaust;
                    destination = a;
                } 
                if (exaust == minExaust) {
                    Random random = new Random();
                    boolean rand = random.nextBoolean();
                    if (rand) {
                        minExaust = exaust;
                        destination = a;
                    }
                }
            }

            return destination;
        }
        
        public Attraction determineDestination (Guest g, Attraction excluded) {
            Attraction destination = rides.get(0);
            
            int minExaust = Integer.MAX_VALUE;
            for (Attraction a : rides) {
                if (g.ridesRiden.contains(a) || a == excluded || a.closed) {
                    continue;
                }
                int exaust = getExaust(g, a);
                
                if (exaust < minExaust) {
                    minExaust = exaust;
                    destination = a;
                } 
                if (exaust == minExaust) {
                    Random random = new Random();
                    boolean rand = random.nextBoolean();
                    if (rand) {
                        minExaust = exaust;
                        destination = a;
                    }
                }
            }

            return destination;
            
        }
        
        public int getExaust(Guest g, Attraction a) {
            int exaust = 0;
                // Exaust from waiting
                exaust += a.totalWaitTime / 1.5;
                
                // Exaust from traveling
                int distance = (int)Point2D.distance(g.location.getX(), g.location.getY(), a.getAccessPoint().getX(), a.getAccessPoint().getY());
                exaust += (distance / 100) * 2;
                
                // excuse some exaust if the ride is age appropriate
                if (a.targetAudience.equalsIgnoreCase(g.age)) {
                    exaust -= 15;
                }
            return exaust;
        }
        
        public void load() {
            try(Scanner fin = new Scanner(new File("C:\\Users\\blake\\Desktop\\WaitPlease\\Save.txt"))){
            if(fin.hasNextLine()) {
                while (fin.hasNextLine()) {
                    String curr = fin.nextLine();
                    String[] arr = curr.split(" ");
                    int i = Integer.parseInt(arr[0]);
                    int j = Integer.parseInt(arr[1]);
                    if (arr[2].equalsIgnoreCase("T")) {
                        bools[i][j] = true;
                        
                    } else {
                        bools[i][j] = false;
                        
                    }   
                }
                
                
                
               
                 
            }
            
        } catch (Exception e) {
                e.printStackTrace();
        }
        }
    
        public static void main(String[] args) {
        MainFrame mainframe = new MainFrame();
        
    }
        
        public Guest earlyExit(Guest g) {
            
            g.setLocation(g.attractionDestination.getEarlyExitPoint());
            g.inLine = false;
            Attraction destination = determineDestination(g, g.attractionDestination);
            
            g.setDestination(destination);
            return g;
        }
        
        
        public void passTime() {
            
            
            boolean oneExiting = false;
            // Priority of movement
            // Up, Down, Right, Left
            for (Guest g : guests) {
                
                // As guests move, they slowly get hungrier
                Random rand = new Random();
                boolean random = rand.nextBoolean();
                if (random) {
                    g.setHungerStatus(g.getHungerStatus() - 1);
                }
                
                if (g.inLine && !oneExiting) {
                    Attraction curr = g.attractionDestination;
                    for (Attraction a : rides) {
                        if (getExaust(g, curr) - getExaust(g, a) > 15) {
                            
                            curr.line.remove(g);
                            g = earlyExit(g);
                            g.previousLocations = new ArrayList<>();
                            oneExiting = true;
                            break;
                            
                        }
                    }
                    
                }
                
                if (g.location.getX() == g.destination.getX() && g.location.getY() == g.destination.getY() && !g.inLine && !g.onRide) {
                    
                    if (g.attractionDestination.addToQueue(g)) {
                        g.inLine = true;
                        if (g.tracking) {
                            trackingModel.addElement("The subject began waiting in line for " + g.attractionDestination.name);
                            
                        }
                        int x = (int)g.location.getX();
                        int y = (int)g.location.getY();
                        occupied[x/10][y/10] = false;
                        
                    }
                    
                }
                if (!g.inLine && !g.onRide) {
                    boolean moved = false;
                    // Up
                    if (g.location.getY() > g.destination.getY()) {
                        int x = (int)g.location.getX();
                        int y = (int)g.location.getY() - 10;
                        if (x > 0 && y > 0) {
                            Point nextLocation = new Point(x, y);
                            if (/*!bools[x/10][y/10] &&*/ !occupied[x/10][y/10] && 
                                    !(g.previousLocations.contains(nextLocation))) {
                                g.setLocation(x, y);
                                occupied[x/10][y/10 + 1] = false;
                                occupied[x/10][y/10] = true;
                                moved = true;
                                g.previousLocations.add(nextLocation);

                            }
                        }
                    }
                    // Down
                    if (g.location.getY() < g.destination.getY() && !moved) {
                        int x = (int)g.location.getX();
                        int y = (int)g.location.getY() + 10;
                        if (x > 0 && y > 0) {
                            Point nextLocation = new Point(x, y);
                            if (/*!bools[x/10][y/10] &&*/ !occupied[x/10][y/10]
                                    && !(g.previousLocations.contains(nextLocation))) {
                                g.setLocation(x, y);
                                occupied[x/10][y/10 - 1] = false;
                                occupied[x/10][y/10] = true;
                                moved = true;
                                g.previousLocations.add(nextLocation);

                            }
                        }
                    }

                    // Left
                    if (g.location.getX() > g.destination.getX() && !moved) {
                        int x = (int)g.location.getX() - 10;
                        int y = (int)g.location.getY();
                        if (x > 0 && y > 0) {
                            Point nextLocation = new Point(x, y);
                            if (/*!bools[x/10][y/10] &&*/ !occupied[x/10][y/10]
                                    && !(g.previousLocations.contains(nextLocation))){
                                g.setLocation(x, y);
                                occupied[x/10 + 1][y/10] = false;
                                occupied[x/10][y/10] = true;
                                moved = true;
                                g.previousLocations.add(nextLocation);

                            }
                        }

                    } 
                    // Right
                    if (g.location.getX() < g.destination.getX() && !moved) {
                        int x = (int)g.location.getX() + 10;
                        int y = (int)g.location.getY();
                        if (x > 0 && y > 0) {
                        
                            Point nextLocation = new Point(x, y);
                            if (/*!bools[x/10][y/10] &&*/ !occupied[x/10][y/10]
                                    && !(g.previousLocations.contains(nextLocation))) {
                                g.setLocation(x, y);
                                occupied[x/10 - 1][y/10] = false;
                                occupied[x/10][y/10] = true;
                                moved = true;
                                g.previousLocations.add(nextLocation);

                            }
                        }

                    }
                    // If they are unable to move
//                    if (!moved) {
//                        Random random2 = new Random();
//                        int choice = random2.nextInt(4);
//                        switch(choice){
//                            // UP
//                            case 0: int x = (int)g.location.getX();
//                                    int y = (int)g.location.getY() - 10;
//                                    if (x > 0 && y > 0) {
//                                        Point nextLocation = new Point(x, y);
//                                        if (!occupied[x/10][y/10]) {
//                                            g.setLocation(x, y);
//                                            occupied[x/10][y/10 + 1] = false;
//                                            occupied[x/10][y/10] = true;
//                                            moved = true;
//                                            
//
//
//                                        }
//                                    }
//                                break;
//                            // Down
//                            case 1: x = (int)g.location.getX();
//                                    y = (int)g.location.getY() + 10;
//                                    if (x > 0 && y > 0) {
//                                    Point nextLocation = new Point(x, y);
//                                        if (!occupied[x/10][y/10]) {
//                                            g.setLocation(x, y);
//                                            occupied[x/10][y/10 - 1] = false;
//                                            occupied[x/10][y/10] = true;
//                                            moved = true;
//                                            
//
//
//                                        }
//                                    }
//                                        
//
//                                    
//                                    break;
//                            case 2: x = (int)g.location.getX() - 10;
//                                    y = (int)g.location.getY();
//                                    if (x > 0 && y > 0) {
//                                        Point nextLocation = new Point(x, y);
//                                        if ( !occupied[x/10][y/10]){
//                                            g.setLocation(x, y);
//                                            occupied[x/10 + 1][y/10] = false;
//                                            occupied[x/10][y/10] = true;
//                                            moved = true;
//                                            
//
//                                        }
//                                    }
//                                    break;
//                            case 3: x = (int)g.location.getX() + 10;
//                                    y = (int)g.location.getY();
//                                    if (x > 0 && y > 0) {
//                                        Point nextLocation = new Point(x, y);
//                                        if (!occupied[x/10][y/10]) {
//                                            g.setLocation(x, y);
//                                            occupied[x/10 - 1][y/10] = false;
//                                            occupied[x/10][y/10] = true;
//                                            moved = true;
//                                            
//
//                                        }
//                                    }
//                                    break;
//                            default: break;
//                            
                       //}
//                        
                    //}
                }
                
                
//                // IF they still haven't moved, move randomly
//                if (!moved) {
//                    // Up
//                    
//                        int x = (int)g.location.getX();
//                        int y = (int)g.location.getY() - 10;
//                        Point nextLocation = new Point(x, y);
//                        if (!bools[x/10][y/10] && !occupied[x/10][y/10] && 
//                                !(g.previousLocations.contains(nextLocation))) {
//                            g.setLocation(x, y);
//                            occupied[x/10][y/10 + 1] = false;
//                            occupied[x/10][y/10] = true;
//                            moved = true;
//                            g.previousLocations.add(nextLocation);
//
//                        }
//                    
//                    // Down
//                    if (!moved) {
//                        x = (int)g.location.getX();
//                        y = (int)g.location.getY() + 10;
//                        nextLocation = new Point(x, y);
//                        if (!bools[x/10][y/10] && !occupied[x/10][y/10]
//                                && !(g.previousLocations.contains(nextLocation))) {
//                            g.setLocation(x, y);
//                            occupied[x/10][y/10 - 1] = false;
//                            occupied[x/10][y/10] = true;
//                            moved = true;
//                            g.previousLocations.add(nextLocation);
//
//                        }
//                    }
//
//                    // Left
//                    if (!moved) {
//                        x = (int)g.location.getX() - 10;
//                        y = (int)g.location.getY();
//                        nextLocation = new Point(x, y);
//                        if (!bools[x/10][y/10] && !occupied[x/10][y/10]
//                                && !(g.previousLocations.contains(nextLocation))){
//                            g.setLocation(x, y);
//                            occupied[x/10 + 1][y/10] = false;
//                            occupied[x/10][y/10] = true;
//                            moved = true;
//                            g.previousLocations.add(nextLocation);
//
//                        }
//
//                    } 
//                    // Right
//                    if (!moved) {
//                        x = (int)g.location.getX() + 10;
//                        y = (int)g.location.getY();
//                        nextLocation = new Point(x, y);
//                        if (!bools[x/10][y/10] && !occupied[x/10][y/10]
//                                && !(g.previousLocations.contains(nextLocation))) {
//                            g.setLocation(x, y);
//                            occupied[x/10 - 1][y/10] = false;
//                            occupied[x/10][y/10] = true;
//                            moved = true;
//                            g.previousLocations.add(nextLocation);
//
//                        }
//
//                    }
//                        
//                
//                    
//                    
//                    
//                    
//                    
//                    
//                    
//                    
//                    
//                }
                // Default Down
                // Default Left
                // Default Right 
                
                
                
                
            panel.repaint();
            }
            
        }
        
        
    
    class myPanel extends JPanel {

        
        public myPanel() {
            setVisible(true);
            addMouseListener(new MouseAdapter() { 
                public void mousePressed(MouseEvent me) { 
                    int xPress = me.getX();
                    int yPress = me.getY();
                    while (xPress % blockSize != 0) {
                        xPress--;
                    }
                    while (yPress % blockSize != 0 ) {
                        yPress--;
                    }
                    int i = xPress/blockSize;
                    int j = yPress/blockSize;
                    
                    
                    System.out.println(xPress + " " + yPress);
                    for (Guest g : guests) {
                        if (g.location.getX() == xPress && g.location.getY() == yPress) {
                            System.out.println(g.attractionDestination.name);
                            for (Guest x : guests) {
                                x.tracking = false;
                            }
                            g.tracking = true;
                            trackingModel = new DefaultListModel();
                        }
                    }
                        
                    
                } 
            });
            
//            this.addMouseMotionListener(new MouseMotionAdapter() {
//                public void mouseDragged(MouseEvent e) {
//                    int xPress = e.getX();
//                    int yPress = e.getY();
//                    while (xPress % blockSize != 0) {
//                        xPress--;
//                    }
//                    while (yPress % blockSize != 0 ) {
//                        yPress--;
//                    }
//                    int i = xPress/blockSize;
//                    int j = yPress/blockSize;
//                    
//                    if (!shiftPressed) {
//                        bools[i][j] = true;
//                    } else {
//                        bools[i][j] = false;
//                    }
//                     
//                    
//                    
//                    repaint();
//                }
//            });
    }
            
            
            
            
        
        @Override
        public void paintComponent(Graphics g) {
           super.paintComponent(g);
           
           g.setColor(Color.BLACK);
           for (int i = 0; i < horizontalSpaces; i++) {
                for (int j = 0; j < verticalSpaces; j++) {
                    g.setColor(Color.BLACK);
                    //g.drawRect((int)spaces[i][j].getX(), (int)spaces[i][j].getY(), blockSize, blockSize);
                    if (bools[i][j]) {
                        g.setColor(new Color(125, 112, 186));
                        g.fillRect((int)spaces[i][j].getX(), (int)spaces[i][j].getY(), blockSize, blockSize);    
                    }
                    if (fills[i][j]) {
                        g.setColor(new Color(239,200,139));
                        g.fillRect((int)spaces[i][j].getX(), (int)spaces[i][j].getY(), blockSize, blockSize);  
                    }
                }
                    
            }
           // Paint Castle
           g.setColor(Color.pink);
           g.fillRect(670, 250, 140, 60);
           g.fillRect(698, 205, 84, 45);
           g.fillRect(740, 175, 42, 30);
           
           g.setColor(Color.black);
           g.fillRect(720, 280, 40, 30);
           g.fillOval(720, 260, 40, 40);
           
           g.setColor(Color.blue);
           //g.fillPolygon(xPoints, yPoints, WIDTH);
            for (Attraction a : rides) {
                
                
                Point p = a.getAccessPoint();
                int xPress = (int)p.getX();
                int yPress = (int)p.getY();
                    while (xPress % blockSize != 0) {
                        xPress--;
                    }
                    while (yPress % blockSize != 0 ) {
                        yPress--;
                    }
                
                
                
                Point p2 = a.getExitPoint();
                int xPress2 = (int)p2.getX();
                int yPress2 = (int)p2.getY();
                while (xPress2 % blockSize != 0) {
                    xPress2--;
                }
                while (yPress2 % blockSize != 0 ) {
                    yPress2--;
                }
                
                Point p3 = a.earlyExitPoint;
                int xPress3 = (int)p3.getX();
                int yPress3 = (int)p3.getY();
                while (xPress3 % blockSize != 0) {
                    xPress3--;
                }
                while (yPress3 % blockSize != 0 ) {
                    yPress3--;
                }
                
                g.setColor(Color.white);
                g.fillRect(xPress, yPress, 60, 60);
                if (!labelsShowing) {
                    g.setColor(Color.black);
                    g.drawRect(xPress, yPress, 60, 60);
                }
                
                
                if (labelsShowing) {
                    a.draw(g);    
                }
                
                
                g.setColor(Color.red);
                g.fillRect(xPress, yPress, blockSize, blockSize);   
                g.setColor(Color.yellow);
                g.fillRect(xPress2, yPress2, blockSize, blockSize);
                g.setColor(Color.lightGray);
                g.fillRect(xPress3, yPress3, blockSize, blockSize);
                
            }
            
            //leaving.draw(g);
            
            for (Guest t : guests) {
                if (!t.inLine && !t.onRide) {
                    t.draw(g);   
                }
            }
           
           

        }

}
    
}

