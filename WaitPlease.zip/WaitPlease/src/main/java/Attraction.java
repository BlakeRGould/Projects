
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author blake
 */
public class Attraction {
    
    public String name;
    
    // The time it takes to unload someone from the ride 
    // This value is based off of the ride hourly capacity
    public int outFlowTime;
    
    // The time it takes for the guest to experience the attraction
    public double expTime;
    
    // The amount of people that can be waiting in the line at one time
    public int lineCapacity = 2000;
    
    // The amount of people that can be on the ride at one time
    public int rideCapacity = 0;
    public String targetAudience;
    public String restaurantType;
    public String type;
    
    
    public int totalWaitTime = 0;
    
    // Determines if the attraction is open to the public
    public boolean closed = false;
    
    public Queue line;
    public Queue ride;
    
    public int x;
    public int y;
    public int width;
    public int height;
    public Color color;
    
    public Point exitPoint;
    public Point earlyExitPoint;
    public Point restuarantAccessPoint;
    public int priority;
    
    // Ride Constructor
    public Attraction(String name, double outFlowTime,  String targetAudience, double expTime, int priority) {
        this.priority = priority;
        this.outFlowTime = (int)(13 * outFlowTime);
        this.rideCapacity = 5000;
        this.expTime = expTime;
        line = new ArrayBlockingQueue(lineCapacity);
        ride = new ArrayBlockingQueue(rideCapacity);
        this.name = name;
        this.targetAudience = targetAudience;
        type = "Ride";
    }
    
    // Restaurant Constructor
//    public Attraction(String name, String restaurantType) {
//        this.name = name;
//        type = "restaurant";
//        this.restaurantType = restaurantType;
//        if (restaurantType.equalsIgnoreCase("Quick Service")) {
//            outFlowTime = 2;
//            expTime = 15;
//            line = new ArrayBlockingQueue(100);
//            ride = new ArrayBlockingQueue(100);
//        } else if (restaurantType.equalsIgnoreCase("SitDown Dining")) {
//            outFlowTime = 4;
//            expTime = 25;
//            line = new ArrayBlockingQueue(100);
//            ride = new ArrayBlockingQueue(100);
//        }
//        
//    }
    
    
    public void setGraphics(int x, int y, int width, int height, Color color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.color = color;
        
        if (type.equalsIgnoreCase("ride")) {
            // Initialize the exit point
            setExitPoint(x + 50, y + 50);

            //Initialize the Early exit point
            setEarlyExitPoint(x + 30, y + 30);
        }
//        } else if (type.equalsIgnoreCase("Restaurant")) {
//            setExitPoint(x + 30, y + 20);
//            this.restuarantAccessPoint = new Point(x + 10, y + 20);
//            
//        }
        
    }
    
    public void draw(Graphics g)
    {
      if (type.equalsIgnoreCase("Ride")) {
          
      
//            g.setColor(Color.white);
//            g.fillOval(x - 3, y - 3, width + 6, height + 6);
//            g.setColor(this.color);
//            g.fillOval(x, y, width, height);
//            g.setColor(Color.black);
//            g.drawString(name , x + (width / 4), y + (height / 2));
//            g.setColor(Color.black);
//
//            g.drawString("[" + String.valueOf(totalWaitTime) + "]", x + (width / 2), y + (height * 3/4));
//
//            g.drawOval(x, y, width, height);
//            g.drawOval(x - 3, y - 3, width + 6, height + 6);

              g.setColor(this.color);
              int length = this.name.length() * 7;
              g.fillRect(this.x , this.y - 10, length, 10);
              if (this.color != Color.white && this.color != Color.yellow && this.color != Color.green) {
                g.setColor(Color.white);    
              } else {
                  g.setColor(Color.BLACK);
              }
              float f = 12.0f;
              g.setFont(g.getFont().deriveFont(f));
              g.drawString(name, x , y );
              
              f=20.0f; // font size.
              g.setColor(Color.black);
              g.setFont(g.getFont().deriveFont(f));
              g.drawString("" + this.getWaitTime(), x + 20, y + 15);
      }
//       } else if (type.equalsIgnoreCase("Restaurant")) {
//           g.setColor(color);
//           g.fillRect(x, y, 50, 30);
//           g.setColor(Color.black);
//           g.drawRect(x, y, 50, 30);
//           g.setColor(Color.white);
//           g.fillRect(x + 10, y + 10, 10, 20);
//           g.fillRect(x + 30, y + 10, 10, 20);
//           
//           // Creates the entrance point
//           g.setColor(Color.red);
//           g.fillRect(x + 10, y + 20, 10, 10);
//           g.setColor(Color.black);
//           g.drawRect(x + 10, y + 20, 10, 10);
//           
//           // Creates the exit point
//           g.setColor(Color.yellow);
//           g.fillRect(x + 30, y + 20, 10, 10);
//           g.setColor(Color.black);
//           g.drawRect(x + 30, y + 20, 10, 10);
//           
//           g.setColor(Color.black);
//           g.drawString(name, x, y - 10);
//       }
    }
    
    public Point getAccessPoint() {
        return new Point(x, y);
    }
    
    public Point getExitPoint() {
        return exitPoint;
    }
    
    public void setExitPoint(int a, int b) {
        exitPoint = new Point(a, b);
    }
    
    public void setEarlyExitPoint(int a, int b) {
        earlyExitPoint = new Point(a, b);
    }
    
    public Point getEarlyExitPoint() {
        return earlyExitPoint;
    }
    
    public boolean addToQueue(Guest g) {
        if (line.size() < lineCapacity) {
            line.add(g);
            return true;
        } else {
            return false;
        }
    }
    
    public void setWaitTime() {
        // The amount of time for an individual if they were to get into the end of the line 
        // queue would be equal to the inFlowTime (0.5 * outflowTime) * # of people in line before them
        // *In minutes PLUS the actual outFlowTime (0.5 * outflowTime) * # of people "on the ride" ahead of them
        totalWaitTime = ((outFlowTime / 2) * line.size()) / 60000;
        totalWaitTime += ((outFlowTime / 2) * ride.size()) / 60000;
        while (totalWaitTime % 5 != 0) {
            totalWaitTime++;
        }
    }
    
    public int getWaitTime() {
        return totalWaitTime;
    }
    
    public String toString() {
        return name + " " + totalWaitTime + " " + line.size() + " " + ride.size();
    }
}
