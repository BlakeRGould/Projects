READ ME FIRST PLEASE

USAGE.txt is the documentation needed for an individual using the system.
USAGE.txt also includes the documentation necessary for running the 
system. TECH.txt is the technical documentation for an individual who 
would like to continue the development of the system.

Team Description and Project Goal:
	Our team consisted of four individuals of different coding 
backgrounds. Our project manager was proficient in front end GUI's.
However, two other members' knowledge of GUI's was vague and one 
member hadn't experienced creating a GUI before. Our goal in this 
project was to create a GUI for a online recipe database with the
backend as a text file. Two texts files were included with this 
project: one for saving the recipe information and one for saving 
the user information. Two individuals from the group worked 
primarily on testing and backend classes which were then used as 
the base for the GUI. The project manager created the GUI and the 
final (fourth) member worked on the algortithms within the system. 
	This allowed the project manager to be familiar with the 
front end that was shown to the customer and it allowed the other 
group members that may have not been as familiar with GUI's to learn. 
This learning was done through the need to integrate the backend with 
the front end and integrate all of the algorithms for searching, 
filtering, logging in etc. This allowed all of us to gain experience 
while delivering a working product. 

